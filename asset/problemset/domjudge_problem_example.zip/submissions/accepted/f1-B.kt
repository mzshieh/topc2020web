import java.util.ArrayDeque

data class Hydra(val head: Int, val tail: Int)

fun main() {
    // read h t
    val (h, t) = readLine()!!.split(" ").map{ it.toInt() }

    // no operation needed
    if (h==0 && t==0) return println(0)

    // prepare to perform a BFS: Initialization
    val queue = ArrayDeque<Hydra>()
    val depth = HashMap<Hydra,Int>()
    depth[Hydra(0,0)] = 0
    queue.addLast(Hydra(0,0))
    while(true) {
        // deque
        val first = queue.removeFirst()

        // if we find the answer, print it and quit
        if (first.head == h && first.tail == t) return println(depth[first])

        // expand the neighbots
        val (fh, ft) = first
        for (newHydra in listOf(Hydra(fh+3,ft),Hydra(fh-2,ft+3),Hydra(fh+2,ft-1),Hydra(fh,ft-2))) {
            // if the neighbor is invalid, drop it.
            if (newHydra in depth || newHydra.head < 0 || newHydra.tail < 0)
                continue

            // put the valid neighbor into the queue.
            depth[newHydra] = depth[first]!! + 1
            queue.addLast(newHydra)
        }
    }
}
